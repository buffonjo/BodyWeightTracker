﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;

namespace BodyWeightTracker
{
    public partial class WorkoutHistory : Window
    {
        public WorkoutHistory()
        {
            InitializeComponent();
            LoadWorkoutHistory();
        }

        private void LoadWorkoutHistory()
        {
            try
            {
                string filePath = GetHistoryFilePath();

                if (File.Exists(filePath))
                {
                    string json = File.ReadAllText(filePath);
                    var history = JsonConvert.DeserializeObject<List<WorkoutHistoryItem>>(json)
                                ?? new List<WorkoutHistoryItem>();

                    HistoryDataGrid.ItemsSource = history;
                }
                else
                {
                    MessageBox.Show("История тренировок пуста.", "Информация",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки истории: {ex.Message}", "Ошибка",
                               MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public static string GetHistoryFilePath()
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "workout_history.json");
        }

        private void ClearHistoryButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите полностью очистить историю тренировок?\nЭто действие нельзя отменить.",
                                        "Подтверждение удаления",
                                        MessageBoxButton.YesNo,
                                        MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    string filePath = GetHistoryFilePath();

                    // Очищаем DataGrid
                    HistoryDataGrid.ItemsSource = null;

                    // Удаляем файл с историей
                    if (File.Exists(filePath))
                    {
                        File.Delete(filePath);
                    }

                    MessageBox.Show("История тренировок успешно очищена.", "Успех",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при очистке истории: {ex.Message}", "Ошибка",
                                   MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
