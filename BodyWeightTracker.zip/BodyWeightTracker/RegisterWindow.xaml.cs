﻿using System;
using System.Data.SQLite;
using System.Windows;

namespace BodyWeightTracker
{
    public partial class RegisterWindow : Window
    {
        private readonly string _connectionString;
        public int UserId { get; private set; } = -1;
        public string Username { get; private set; } = "";

        public RegisterWindow(string connectionString)
        {
            InitializeComponent();
            _connectionString = connectionString;
        }
        private void LoginLink_Click(object sender, RoutedEventArgs e)
        {
            OpenLoginWindow();
        }
        private void OpenLoginWindow()
        {
            LoginWindow loginWindow = new LoginWindow(_connectionString);
            loginWindow.Show();
            this.Close();
        }
        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин и пароль!");
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают!");
                return;
            }

            try
            {
                using (var connection = new SQLiteConnection(_connectionString))
                {
                    connection.Open();
                    var command = new SQLiteCommand(
                        "INSERT INTO Users (Username, Password) VALUES (@Username, @Password); " +
                        "SELECT last_insert_rowid();",
                        connection);

                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password); // В реальном приложении используйте хеширование!

                    UserId = Convert.ToInt32(command.ExecuteScalar());
                    Username = username;
                    DialogResult = true;
                    Close();
                }
            }
            catch (SQLiteException ex) when (ex.ResultCode == SQLiteErrorCode.Constraint)
            {
                MessageBox.Show("Пользователь с таким логином уже существует!");
            }
            catch
            {
                MessageBox.Show("Ошибка при регистрации!");
            }
        }
    }
}