﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using BodyWeightTracker;
using Dapper;
using static BodyWeightTracker.AddTemplateWindow;

public class DatabaseService
{
    private SQLiteConnection _connection;
    private readonly string _connectionString;

    public DatabaseService()
    {
        string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "workouts.db");
        _connectionString = $"Data Source={dbPath};Version=3;";
        _connection = new SQLiteConnection(_connectionString);
        InitializeDatabase();
    }

    public DatabaseService(string connectionString)
    {
        _connectionString = connectionString;
        _connection = new SQLiteConnection(_connectionString);
        InitializeDatabase();
    }

    private void InitializeDatabase()
    {
        _connection.Open();

        // Создание таблицы шаблонов тренировок (ваша оригинальная структура)
        var createTemplates = @"
        CREATE TABLE IF NOT EXISTS Templates (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL,
            MuscleGroup TEXT,
            Difficulty TEXT,
            UserId INTEGER,
            CreationDate DATETIME DEFAULT CURRENT_TIMESTAMP
        )";

        // Создание таблицы упражнений (ваша оригинальная структура)
        var createExercises = @"
        CREATE TABLE IF NOT EXISTS Exercises (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            TemplateId INTEGER,
            Name TEXT NOT NULL,
            Sets INTEGER,
            Reps INTEGER,
            FOREIGN KEY(TemplateId) REFERENCES Templates(Id)
        )";

     

        new SQLiteCommand(createTemplates, _connection).ExecuteNonQuery();
        new SQLiteCommand(createExercises, _connection).ExecuteNonQuery();
      

       
    }

    
    

    // Ваши оригинальные методы
    public List<WorkoutTemplate> GetUserTemplates(int userId)
    {
        return _connection.Query<WorkoutTemplate>(
            "SELECT * FROM Templates WHERE UserId = @UserId ORDER BY CreationDate DESC",
            new { UserId = userId }).ToList();
    }

    public void SaveTemplate(WorkoutTemplate template, List<Exercise> exercises)
    {
        using (var transaction = _connection.BeginTransaction())
        {
            try
            {
                // Сохраняем шаблон
                var templateId = _connection.ExecuteScalar<int>(
                    @"INSERT INTO Templates (Name, MuscleGroup, Difficulty, UserId, CreationDate) 
                    VALUES (@Name, @MuscleGroup, @Difficulty, @UserId, @CreationDate);
                    SELECT last_insert_rowid()",
                    template, transaction);

                // Сохраняем упражнения
                foreach (var exercise in exercises)
                {
                    _connection.Execute(
                        @"INSERT INTO Exercises (TemplateId, Name, Sets, Reps) 
                        VALUES (@TemplateId, @Name, @Sets, @Reps)",
                        new
                        {
                            TemplateId = templateId,
                            exercise.Name,
                            exercise.Sets,
                            exercise.Reps
                        }, transaction);
                }

                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }
    }

    

    public void Close()
    {
        _connection?.Close();
        _connection?.Dispose();
    }
}

// Дополнительный класс для базовых упражнений
public class BaseExercise
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string MuscleGroup { get; set; }
    public string Difficulty { get; set; }
    public int DefaultSets { get; set; }
    public int DefaultReps { get; set; }
}