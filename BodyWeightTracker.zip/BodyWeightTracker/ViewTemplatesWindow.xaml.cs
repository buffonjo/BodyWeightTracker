﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static BodyWeightTracker.AddTemplateWindow;


namespace BodyWeightTracker
{
    /// <summary>
    /// Логика взаимодействия для ViewTemplatesWindow.xaml
    /// </summary>
    public partial class ViewTemplatesWindow : Window
    {
        private readonly int _userId;
        private readonly string _connectionString;

        public ViewTemplatesWindow(int userId, string connectionString)
        {
            InitializeComponent();
            _userId = userId;
            _connectionString = connectionString;
            LoadTemplates();
        }

        private void LoadTemplates()
        {
            try
            {
                using (var connection = new SQLiteConnection(_connectionString))
                {
                    connection.Open();

                    var cmd = new SQLiteCommand(
                        @"SELECT Id, Name, Exercises FROM Templates 
                        WHERE UserId = @userId 
                        ORDER BY Id DESC", connection);

                    cmd.Parameters.AddWithValue("@userId", _userId);

                    var templates = new List<WorkoutTemplate>();

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var exercisesJson = reader["Exercises"].ToString();
                            var exercises = JsonConvert.DeserializeObject<List<Exercise>>(exercisesJson);

                            templates.Add(new WorkoutTemplate
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Name = reader["Name"].ToString(),
                                Exercises = exercises
                            });
                        }
                    }

                    TemplatesListView.Items.Refresh();
                    TemplatesListView.ItemsSource = templates;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки шаблонов: {ex.Message}");
            }
        }
        private void SelectTemplate_Click(object sender, RoutedEventArgs e)
        {
            if (((Button)sender).Tag is WorkoutTemplate selectedTemplate)
            {
                // Создаем новое окно и передаем ВСЕ данные шаблона
                var detailsWindow = new TemplateDetailsWindow(
                    new WorkoutTemplate
                    {
                        Id = selectedTemplate.Id,
                        Name = selectedTemplate.Name,
                        Exercises = selectedTemplate.Exercises.ToList() // Полная копия
                    })
                {
                    Owner = this,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner
                };

                detailsWindow.ShowDialog();
            }
        }

        private void DeleteTemplate_Click(object sender, RoutedEventArgs e)
        {
            if (((Button)sender).Tag is WorkoutTemplate template)
            {
                if (MessageBox.Show("Удалить этот шаблон?", "Подтверждение",
                    MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    DeleteTemplate(template.Id);
                }
            }
        }

        private void DeleteTemplate(int templateId)
        {
            try
            {
                using (var connection = new SQLiteConnection(_connectionString))
                {
                    connection.Open();

                    var cmd = new SQLiteCommand(
                        "DELETE FROM Templates WHERE Id = @id", connection);
                    cmd.Parameters.AddWithValue("@id", templateId);

                    cmd.ExecuteNonQuery();
                    LoadTemplates(); // Обновляем список
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}");
            }
        }


        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

}