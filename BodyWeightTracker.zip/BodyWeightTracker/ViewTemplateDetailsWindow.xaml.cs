﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static BodyWeightTracker.AddTemplateWindow;

namespace BodyWeightTracker
{
    /// <summary>
    /// Логика взаимодействия для ViewTemplateDetailsWindow.xaml
    /// </summary>
    public partial class TemplateDetailsWindow : Window
    {
        public ObservableCollection<Exercise> Exercises { get; } = new ObservableCollection<Exercise>();
        private readonly List<Exercise> _exercisesList = new List<Exercise>();

        public TemplateDetailsWindow(WorkoutTemplate template)
        {
            InitializeComponent();
            WindowStartupLocation = WindowStartupLocation.CenterOwner;

            if (template?.Exercises != null)
            {
                foreach (var exercise in template.Exercises)
                {
                    Exercises.Add(exercise);
                    _exercisesList.Add(exercise);
                }
            }

            Title = template?.Name ?? "Детали шаблона";
            DataContext = this;
        }

       private void StartWorkoutButton_Click(object sender, RoutedEventArgs e)
    {
        var workoutExercises = new List<Exercise>();
        foreach (var exercise in _exercisesList)
        {
            workoutExercises.Add(new Exercise
            {
                Name = exercise.Name,
                Sets = exercise.Sets,
                Reps = exercise.Reps,
                MuscleGroup = exercise.MuscleGroup,
                Difficulty = exercise.Difficulty,
                ImagePath = exercise.ImagePath
            });
        }

        var activeWorkoutWindow = new ActiveWorkoutWindow(workoutExercises, this)
        {
            Owner = this,
            WindowStartupLocation = WindowStartupLocation.CenterOwner
        };

        this.Hide();
        activeWorkoutWindow.ShowDialog();
        this.Show();
    }


        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}