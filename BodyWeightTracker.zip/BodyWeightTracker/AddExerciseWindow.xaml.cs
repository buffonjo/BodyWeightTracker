﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace BodyWeightTracker
{
    public partial class AddExerciseWindow : Window
    {
        public string ExerciseName { get; private set; }
        public int Sets { get; private set; }
        public int Reps { get; private set; }
        public string MuscleGroup { get; private set; }
        public string Difficulty { get; private set; }
        public string ImagePath { get; set; }

        public AddExerciseWindow()
        {
            InitializeComponent();
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            SizeToContent = SizeToContent.WidthAndHeight;
        }

        private void LoadImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image files (*.jpg, *.jpeg, *.png)|*.jpg;*.jpeg;*.png",
                Title = "Выберите изображение упражнения"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    // Сохраняем изображение в папку приложения
                    string appImageDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ExerciseImages");
                    Directory.CreateDirectory(appImageDir);

                    string uniqueFileName = $"{Guid.NewGuid()}{Path.GetExtension(openFileDialog.FileName)}";
                    ImagePath = Path.Combine(appImageDir, uniqueFileName);

                    File.Copy(openFileDialog.FileName, ImagePath, true);

                    // Показываем превью
                    ExerciseImagePreview.Source = new BitmapImage(new Uri(ImagePath));
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении изображения: {ex.Message}");
                }
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка ввода
            if (string.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                MessageBox.Show("Введите название упражнения!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(SetsTextBox.Text, out int sets) || sets <= 0)
            {
                MessageBox.Show("Введите корректное количество подходов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(RepsTextBox.Text, out int reps) || reps <= 0)
            {
                MessageBox.Show("Введите корректное количество повторений!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MuscleGroupComboBox.SelectedItem == null)
            {
                MessageBox.Show("Выберите группу мышц!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (DifficultyComboBox.SelectedItem == null)
            {
                MessageBox.Show("Выберите уровень сложности!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Сохранение данных
            ExerciseName = NameTextBox.Text;
            Sets = sets;
            Reps = reps;
            MuscleGroup = MuscleGroupComboBox.SelectedItem.ToString();
            Difficulty = DifficultyComboBox.SelectedItem.ToString();
            ImagePath = ExerciseImagePreview.Source == null ? null : ImagePath;

            // ImageData уже сохранён при загрузке изображения
            DialogResult = true;
            Close();
        }
    }
}