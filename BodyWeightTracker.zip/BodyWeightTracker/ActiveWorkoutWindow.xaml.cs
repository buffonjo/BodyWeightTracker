﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace BodyWeightTracker
{
    public partial class ActiveWorkoutWindow : Window
    {
        private readonly List<Exercise> _exercises;
        private int _currentExerciseIndex = 0;
        private int _currentSet = 1;
        private int _totalSets;
        private int _completedSets = 0;
        private List<WorkoutHistoryItem> completedWorkout = new List<WorkoutHistoryItem>();
        public ActiveWorkoutWindow(List<Exercise> exercises)
        {
            InitializeComponent();
            _exercises = exercises;
            _totalSets = CalculateTotalSets();
            UpdateExerciseDisplay();
        }
        private readonly Dictionary<string, string> _exerciseImages = new Dictionary<string, string>
        {
            // Грудь
    {"Жим штанги лежа", "/Resources/Жим штанги лежа.jpg"},
    {"Жим гантелей на наклонной скамье", "/Resources/Жим гантелей на наклонной скамье.jpg"},
    {"Разводка гантелей", "/Resources/Разводка гантелей.jpg"},
    {"Отжимания на брусьях", "/Resources/Отжимания на брусьях.jpg"},
    {"Пуловер с гантелью", "/Resources/Пуловер с гантелью.jpg"},
    {"Жим в тренажёре Hammer Strength", "/Resources/Жим в тренажёре Hammer Strength.jpg"},
    
    // Спина
    {"Подтягивания", "/Resources/Подтягивания.jpg"},
    {"Тяга штанги в наклоне", "/Resources/Тяга штанги в наклоне.jpg"},
    {"Тяга верхнего блока", "/Resources/Тяга верхнего блока.jpg"},
    {"Тяга гантели одной рукой", "/Resources/Тяга гантели одной рукой.jpg"},
    {"Гиперэкстензия", "/Resources/Гиперэкстензия.jpg"},
    {"Становая тяга", "/Resources/Становая тяга.jpg"},
    
    // Ноги
    {"Приседания со штангой", "/Resources/Приседания со штангой.jpg"},
    {"Жим ногами", "/Resources/Жим ногами.jpg"},
    {"Выпады с гантелями", "/Resources/Выпады с гантелями.jpg"},
    {"Румынская тяга", "/Resources/Румынская тяга.jpg"},
    {"Подъёмы на носки стоя", "/Resources/Подъёмы на носки стоя.jpg"},
    {"Болгарские сплит-приседания", "/Resources/Болгарские сплит-приседания.jpg"},
    
    // Руки
    {"Подъем штанги на бицепс", "/Resources/Подъем штанги на бицепс.jpg"},
    {"Французский жим", "/Resources/Французский жим.jpg"},
    {"Молотки с гантелями", "/Resources/Молотки с гантелями.jpg"},
    {"Разгибания на блоке (трицепс)", "/Resources/Разгибания на блоке (трицепс).jpg"},
    {"Концентрированный подъем на бицепс", "/Resources/Концентрированный подъем на бицепс.jpg"},
    {"Подтягивания обратным хватом", "/Resources/Подтягивания обратным хватом.jpg"},
    
    // Плечи
    {"Жим штанги стоя", "/Resources/Жим штанги стоя.jpg"},
    {"Махи гантелями в стороны", "/Resources/Махи гантелями в стороны.jpg"},
    {"Тяга штанги к подбородку", "/Resources/Тяга штанги к подбородку.jpg"},
    {"Жим Арнольда", "/Resources/Жим Арнольда.jpg"},
    {"Подъемы гантелей перед собой", "/Resources/Подъемы гантелей перед собой.jpg"},
    {"Жим гантелей сидя с паузой", "/Resources/Жим гантелей сидя с паузой.jpg"},
    
    // Пресс
    {"Скручивания", "/Resources/Скручивания.jpg"},
    {"Подъем ног в висе", "/Resources/Подъем ног в висе.jpg"},
    {"Планка (30 сек)", "/Resources/Планка (30 сек).jpg"},
    {"Русские скручивания", "/Resources/Русские скручивания.jpg"},
    {"Велосипед", "/Resources/Велосипед.jpg"},
    {"Дровосек с тросом", "/Resources/Дровосек с тросом.jpg"}
        };

        private int CalculateTotalSets()
        {
            return _exercises.Sum(ex => ex.Sets);
        }

        private void UpdateExerciseDisplay()
        {
            if (_currentExerciseIndex >= _exercises.Count)
            {
                FinishWorkout();
                return;
            }

            var currentExercise = _exercises[_currentExerciseIndex];
            CurrentExerciseText.Text = currentExercise.Name;
            SetsRepsText.Text = $"Подход {_currentSet}/{currentExercise.Sets} | Повторений: {currentExercise.Reps}";
            WorkoutProgress.Value = (_completedSets / (double)_totalSets) * 100;
            UpdateExerciseImage(currentExercise);
        }
        private readonly TemplateDetailsWindow _parentWindow; // Добавляем ссылку на родительское окно

        // Изменяем конструктор
        public ActiveWorkoutWindow(List<Exercise> exercises, TemplateDetailsWindow parentWindow)
        {
            InitializeComponent();
            _exercises = exercises;
            _parentWindow = parentWindow; // Сохраняем ссылку на родительское окно
            _totalSets = CalculateTotalSets();
            UpdateExerciseDisplay();
        }
        private void FinishWorkout()
        {
            SaveCompletedWorkout();

            if (_currentExerciseIndex >= _exercises.Count)
            {
                MessageBox.Show("Тренировка завершена!", "Завершение",
                      MessageBoxButton.OK, MessageBoxImage.Information);
            }

            Close();
        }
        private void UpdateExerciseImage(Exercise exercise)
        {
            try
            {
                // 1. Пробуем загрузить пользовательское изображение (если оно есть и файл существует)
                if (!string.IsNullOrEmpty(exercise.ImagePath) && File.Exists(exercise.ImagePath))
                {
                    var image = new BitmapImage();
                    image.BeginInit();
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.UriSource = new Uri(exercise.ImagePath);
                    image.EndInit();
                    ExerciseImage.Source = image;
                    return;
                }

                // 2. Пробуем загрузить стандартное изображение из ресурсов
                if (_exerciseImages.TryGetValue(exercise.Name, out var defaultImagePath))
                {
                    var defaultImage = new BitmapImage(new Uri(defaultImagePath, UriKind.Relative));
                    ExerciseImage.Source = defaultImage;
                    return;
                }

                // 3. Загружаем изображение по умолчанию
                SetDefaultImage();
            }
            catch (Exception ex)
            {
                // Логируем ошибку и устанавливаем изображение по умолчанию
                Console.WriteLine($"Ошибка загрузки изображения: {ex.Message}");
                SetDefaultImage();
            }
        }

        private void LoadDefaultExerciseImage(string exerciseName)
        {
            // Пытаемся загрузить из встроенных ресурсов
            if (_exerciseImages.TryGetValue(exerciseName, out string imagePath))
            {
                try
                {
                    ExerciseImage.Source = new BitmapImage(new Uri(imagePath, UriKind.RelativeOrAbsolute));
                }
                catch
                {
                    SetDefaultImage();
                }
            }
            else
            {
                SetDefaultImage();
            }
        }

        private void SetDefaultImage()
        {
            try
            {
                var defaultImage = new BitmapImage(
                    new Uri("pack://application:,,,/Resources/default_exercise.jpg"));
                ExerciseImage.Source = defaultImage;
            }
            catch
            {
                // Если даже изображение по умолчанию не загружается, очищаем
                ExerciseImage.Source = null;
            }
        }
        private void CompleteSetBtn_Click(object sender, RoutedEventArgs e)
        {
            _exercises[_currentExerciseIndex].CompletedSets++;
            _completedSets++;
            _currentSet++;

            if (_currentSet > _exercises[_currentExerciseIndex].Sets)
            {
                _currentExerciseIndex++;
                _currentSet = 1;
            }

            UpdateExerciseDisplay();
        }
        private void SaveCompletedWorkout()
        {
            try
            {
                var history = new List<WorkoutHistoryItem>();

                foreach (var exercise in _exercises)
                {
                    int completedReps = exercise.CompletedSets > 0 ? exercise.Reps : 0;
                    history.Add(new WorkoutHistoryItem
                    {
                        WorkoutDate = DateTime.Now,
                        ExerciseName = exercise.Name,
                        Sets = exercise.CompletedSets, // Сохраняем только выполненные подходы
                        Reps = completedReps,
                        MuscleGroup = exercise.MuscleGroup,
                        Difficulty = exercise.Difficulty
                    });
                }

                string filePath = WorkoutHistory.GetHistoryFilePath();
                List<WorkoutHistoryItem> existingHistory = new List<WorkoutHistoryItem>();

                if (File.Exists(filePath))
                {
                    string json = File.ReadAllText(filePath);
                    existingHistory = JsonConvert.DeserializeObject<List<WorkoutHistoryItem>>(json)
                                    ?? new List<WorkoutHistoryItem>();
                }

                existingHistory.AddRange(history);

                string updatedJson = JsonConvert.SerializeObject(existingHistory, Formatting.Indented);
                File.WriteAllText(filePath, updatedJson);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения тренировки: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void SkipExerciseBtn_Click(object sender, RoutedEventArgs e)
        {
            _completedSets += _exercises[_currentExerciseIndex].Sets - _exercises[_currentExerciseIndex].CompletedSets;
            _currentExerciseIndex++;
            _currentSet = 1;
            UpdateExerciseDisplay();
        }

        private void FinishWorkoutBtn_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Завершить тренировку?", "Подтверждение",
                   MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                FinishWorkout(); // Используем новый метод завершения
            }
        }
        private void SaveWorkoutHistory(List<WorkoutHistoryItem> history)
        {
            string filePath = "workout_history.json";

            List<WorkoutHistoryItem> existingHistory = new List<WorkoutHistoryItem>();
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                existingHistory = JsonConvert.DeserializeObject<List<WorkoutHistoryItem>>(json) ?? new List<WorkoutHistoryItem>();
            }

            existingHistory.AddRange(history);

            string updatedJson = JsonConvert.SerializeObject(existingHistory, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);
        }
    }
}