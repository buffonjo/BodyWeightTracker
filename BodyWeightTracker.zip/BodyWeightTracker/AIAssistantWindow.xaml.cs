﻿using System;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Newtonsoft.Json;
using System.IO;

namespace BodyWeightTracker
{
    public partial class AIAssistantWindow : Window
    {
        private const string ApiKey = "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";
        private static readonly string AppDataPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "BodyWeightTracker");

        private static readonly string ChatHistoryPath = Path.Combine(AppDataPath, "chat_history.json");

        public ObservableCollection<ChatMessage> ChatMessages { get; } = new ObservableCollection<ChatMessage>();
        private readonly HttpClient _httpClient = new HttpClient();
        public AIAssistantWindow()
        {
            InitializeComponent();
            DataContext = this;
            ChatMessagesContainer.ItemsSource = ChatMessages;
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", ApiKey);

            // Загрузка истории при запуске
            LoadChatHistory();

            if (ChatMessages.Count == 0)
            {
                AddWelcomeMessage();
            }
        }
        private void AddWelcomeMessage()
        {
            ChatMessages.Add(new ChatMessage
            {
                Text = "Привет! Я ваш фитнес-ассистент. Задавайте вопросы о тренировках, питании и здоровье.",
                IsUserMessage = false,
                Timestamp = DateTime.Now
            });
        }
        private void LoadChatHistory()
        {
            try
            {
                if (!File.Exists(ChatHistoryPath)) return;

                var json = File.ReadAllText(ChatHistoryPath);
                var messages = JsonConvert.DeserializeObject<ObservableCollection<ChatMessage>>(json);

                ChatMessages.Clear();
                foreach (var message in messages)
                {
                    ChatMessages.Add(message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки истории: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void SaveChatHistory()
        {
            try
            {
                if (!Directory.Exists(AppDataPath))
                {
                    Directory.CreateDirectory(AppDataPath);
                }

                var json = JsonConvert.SerializeObject(ChatMessages, Formatting.Indented);
                File.WriteAllText(ChatHistoryPath, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения истории: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SaveChatHistory();
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            InitializeComponent();
            if (string.IsNullOrWhiteSpace(MessageTextBox.Text))
                return;

            var userMessage = MessageTextBox.Text.Trim();
            ChatMessages.Add(new ChatMessage { Text = userMessage, IsUserMessage = true });
            MessageTextBox.Clear();

            try
            {
                var aiResponse = await GetAIResponse(userMessage);
                ChatMessages.Add(new ChatMessage { Text = aiResponse, IsUserMessage = false });
            }
            catch (Exception ex)
            {
                ChatMessages.Add(new ChatMessage
                {
                    Text = $"⚠️ Ошибка: {ex.Message}",
                    IsUserMessage = false
                });
            }
        }
        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Очистить всю историю чата?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                ChatMessages.Clear();
                try
                {
                    if (File.Exists(ChatHistoryPath))
                    {
                        File.Delete(ChatHistoryPath);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления истории: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }
        }
        
        private async Task<string> GetAIResponse(string userMessage)
        {
            var requestData = new
            {
                model = "gpt-3.5-turbo",
                messages = new[]
                {
                    new { role = "system", content = "You are a helpful fitness assistant. Answer in Russian." },
                    new { role = "user", content = userMessage }
                },
                temperature = 0.7
            };

            var content = new StringContent(
                JsonConvert.SerializeObject(requestData),
                Encoding.UTF8,
                "application/json");

            var response = await _httpClient.PostAsync(
                "https://openrouter.ai/api/v1/chat/completions",
                content);

            response.EnsureSuccessStatusCode();

            var responseString = await response.Content.ReadAsStringAsync();
            dynamic responseData = JsonConvert.DeserializeObject(responseString);
            return responseData.choices[0].message.content;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

    public class ChatMessage
    {
        public string Text { get; set; }
        public bool IsUserMessage { get; set; }
        public DateTime Timestamp { get; set; }
    }
}