﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using static BodyWeightTracker.AddTemplateWindow;

namespace BodyWeightTracker
{
    public partial class WorkoutSelectionWindow : Window
    {
        public List<Exercise> SelectedExercises { get; private set; }

        public WorkoutSelectionWindow()
        {
            InitializeComponent();

            // Заполняем ComboBox группами мышц
            MuscleGroupComboBox.ItemsSource = new List<string>
            {
                "Грудь", "Спина", "Ноги", "Руки", "Плечи", "Пресс"
            };

            // Заполняем ComboBox уровнями сложности
            DifficultyComboBox.ItemsSource = new List<string>
            {
                "Начинающий", "Средний", "Продвинутый"
            };
        }

        private void StartWorkout_Click(object sender, RoutedEventArgs e)
        {
            string selectedGroup = MuscleGroupComboBox.SelectedItem?.ToString();
            string selectedDifficulty = DifficultyComboBox.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedGroup) || string.IsNullOrEmpty(selectedDifficulty))
            {
                MessageBox.Show("Выберите группу мышц и уровень сложности!");
                return;
            }

            // Получаем упражнения в зависимости от выбора
            SelectedExercises = GetExercisesForSelection(selectedGroup, selectedDifficulty);

            // Открываем окно активной тренировки
            var activeWorkoutWindow = new ActiveWorkoutWindow(SelectedExercises)
            {
                Owner = this,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };

            this.Hide();
            activeWorkoutWindow.ShowDialog();
            this.Show();
        }
        public Exercise CreateExercise(string name, int sets, int reps, string muscleGroup, string difficulty)
        {
            return new Exercise
            {
                Name = name,
                Sets = sets,
                Reps = reps,
                MuscleGroup = muscleGroup,
                Difficulty = difficulty,
                CompletedSets = 0
            };
        }
        private List<Exercise> GetExercisesForSelection(string muscleGroup, string difficulty)
        {
            var exercises = new List<Exercise>();
            var random = new Random(); // Для перемешивания списка

            switch (muscleGroup)
            {
                case "Грудь":
                    exercises.Add(CreateExercise("Жим штанги лежа", 4, 8, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Жим гантелей на наклонной скамье", 3, 10, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Разводка гантелей", 3, 12, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Отжимания на брусьях", 4, difficulty == "Начинающий" ? 8 : 12, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Пуловер с гантелью", 3, 10, muscleGroup, difficulty));
                    if (difficulty == "Продвинутый")
                        exercises.Add(CreateExercise("Жим в тренажёре Hammer Strength", 4, 10, muscleGroup, difficulty));
                    break;

                case "Спина":
                    exercises.Add(CreateExercise("Подтягивания", 3, difficulty == "Начинающий" ? 5 : 8, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Тяга штанги в наклоне", 4, 8, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Тяга верхнего блока", 3, 10, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Тяга гантели одной рукой", 3, 10, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Гиперэкстензия", 3, 12, muscleGroup, difficulty));
                    if (difficulty == "Продвинутый")
                        exercises.Add(CreateExercise("Становая тяга", 4, 6, muscleGroup, difficulty));
                    break;

                case "Ноги":
                    exercises.Add(CreateExercise("Приседания со штангой", 4, 8, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Жим ногами", 3, 10, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Выпады с гантелями", 3, 10, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Румынская тяга", 3, 8, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Подъёмы на носки стоя", 3, 15, muscleGroup, difficulty));
                    if (difficulty == "Продвинутый")
                        exercises.Add(CreateExercise("Болгарские сплит-приседания", 4, 8, muscleGroup, difficulty));
                    break;

                case "Руки":
                    exercises.Add(CreateExercise("Подъем штанги на бицепс", 3, 10, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Французский жим", 3, 10, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Молотки с гантелями", 3, 12, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Разгибания на блоке (трицепс)", 3, 12, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Концентрированный подъем на бицепс", 3, 10, muscleGroup, difficulty));
                    if (difficulty == "Продвинутый")
                        exercises.Add(CreateExercise("Подтягивания обратным хватом", 4, 8, muscleGroup, difficulty));
                    break;

                case "Плечи":
                    exercises.Add(CreateExercise("Жим штанги стоя", 4, 8, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Махи гантелями в стороны", 3, 12, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Тяга штанги к подбородку", 3, 10, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Жим Арнольда", 3, 10, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Подъемы гантелей перед собой", 3, 12, muscleGroup, difficulty));
                    if (difficulty == "Продвинутый")
                        exercises.Add(CreateExercise("Жим гантелей сидя с паузой", 4, 8, muscleGroup, difficulty));
                    break;

                case "Пресс":
                    exercises.Add(CreateExercise("Скручивания", 3, 15, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Подъем ног в висе", 3, 12, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Планка (30 сек)", 3, 1, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Русские скручивания", 3, 12, muscleGroup, difficulty));
                    exercises.Add(CreateExercise("Велосипед", 3, 15, muscleGroup, difficulty));
                    if (difficulty == "Продвинутый")
                        exercises.Add(CreateExercise("Дровосек с тросом", 4, 12, muscleGroup, difficulty));
                    break;
            }

            // Корректировка подходов и повторений в зависимости от сложности
            switch (difficulty)
            {
                case "Начинающий":
                    exercises.ForEach(ex =>
                    {
                        ex.Sets = Math.Max(2, ex.Sets - 1);
                        ex.Reps = (int)(ex.Reps * 0.8);
                    });
                    break;

                case "Средний":
                    // Базовые значения уже подходят для среднего уровня
                    break;

                case "Продвинутый":
                    exercises.ForEach(ex =>
                    {
                        ex.Sets += 1;
                        ex.Reps = (int)(ex.Reps * 1.2);
                    });
                    break;
            }

            // Перемешиваем упражнения в случайном порядке
            exercises = exercises.OrderBy(x => random.Next()).ToList();

            return exercises;
        }
    }
}