﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Media.Imaging;

namespace BodyWeightTracker
{
    public partial class AddTemplateWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private ObservableCollection<Exercise> _exercisesList = new ObservableCollection<Exercise>();
        public ObservableCollection<Exercise> ExercisesList
        {
            get => _exercisesList;
            set
            {
                _exercisesList = value;
                OnPropertyChanged();
            }
        }

        private readonly string _connectionString;
        private readonly int _userId;

        public AddTemplateWindow(string connectionString, int userId)
        {
            InitializeComponent();
            _connectionString = connectionString;
            _userId = userId;
            InitializeControls();
            ExercisesListView.ItemsSource = ExercisesList;
        }

        private void InitializeControls()
        {
            // Создаем директорию для изображений, если ее нет
            string imageDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ExerciseImages");
            Directory.CreateDirectory(imageDir);
        }

        private void AddExercise_Click(object sender, RoutedEventArgs e)
        {
            var addWindow = new AddExerciseWindow();
            if (addWindow.ShowDialog() == true)
            {
                var exercise = new Exercise
                {
                    Name = addWindow.ExerciseName,
                    Sets = addWindow.Sets,
                    Reps = addWindow.Reps,
                    MuscleGroup = addWindow.MuscleGroup,
                    Difficulty = addWindow.Difficulty,
                    ImagePath = addWindow.ImagePath // Сохраняем путь к изображению
                };

                ExercisesList.Add(exercise);
            }
        }

        private void RemoveExercise_Click(object sender, RoutedEventArgs e)
        {
            if (ExercisesListView.SelectedItem is Exercise selected)
            {
                // Удаляем связанное изображение, если оно есть
                if (!string.IsNullOrEmpty(selected.ImagePath) && File.Exists(selected.ImagePath))
                {
                    try
                    {
                        File.Delete(selected.ImagePath);
                    }
                    catch { /* Игнорируем ошибки удаления */ }
                }

                ExercisesList.Remove(selected);
                ExercisesListView.Items.Refresh();
            }
        }

        public void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TemplateNameTextBox.Text))
            {
                MessageBox.Show("Введите название шаблона!");
                return;
            }

            if (ExercisesList.Count == 0)
            {
                MessageBox.Show("Добавьте хотя бы одно упражнение!");
                return;
            }

            try
            {
                var template = new WorkoutTemplate
                {
                    Name = TemplateNameTextBox.Text.Trim(),
                    Exercises = ExercisesList.ToList()
                };

                SaveTemplateToDatabase(template);
                MessageBox.Show("Шаблон успешно сохранен!");
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}");
            }
        }

        private void SaveTemplateToDatabase(WorkoutTemplate template)
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();
                var exercisesJson = JsonConvert.SerializeObject(template.Exercises);

                var cmd = new SQLiteCommand(
                    @"INSERT INTO Templates (UserId, Name, Exercises)
                      VALUES (@userId, @name, @exercises)", connection);

                cmd.Parameters.AddWithValue("@userId", _userId);
                cmd.Parameters.AddWithValue("@name", template.Name);
                cmd.Parameters.AddWithValue("@exercises", exercisesJson);

                cmd.ExecuteNonQuery();
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем временные изображения при отмене
            foreach (var exercise in ExercisesList)
            {
                if (!string.IsNullOrEmpty(exercise.ImagePath) && File.Exists(exercise.ImagePath))
                {
                    try
                    {
                        File.Delete(exercise.ImagePath);
                    }
                    catch { /* Игнорируем ошибки удаления */ }
                }
            }

            DialogResult = false;
            Close();
        }






        public class WorkoutTemplate
        {
            public string ImagePath { get; set; }
            public int Id { get; set; }
            public string Name { get; set; }
            public List<Exercise> Exercises { get; set; }
        }
    }
}