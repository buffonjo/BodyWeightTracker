﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.IO;
using System.Windows;


namespace BodyWeightTracker
{
    public partial class MainWindow : Window
    {
        private readonly string _connectionString = "Data Source=" +
    System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "users.db") +
    ";FailIfMissing=False;";
        private int _currentUserId = -1;
        private string _currentUsername = "";

        public MainWindow()
        {
            InitializeComponent();
            InitializeDatabase();
         
            UpdateUI();
        }

        private void InitializeDatabase()
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();

                // Создаем таблицу пользователей, если ее нет
                var createTableCmd = new SQLiteCommand(
                    @"CREATE TABLE IF NOT EXISTS Users (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Username TEXT UNIQUE NOT NULL,
                        Password TEXT NOT NULL
                    )", connection);
                createTableCmd.ExecuteNonQuery();
                // Таблица шаблонов (добавляем этот код)
                var createTemplatesTableCmd = new SQLiteCommand(
           @"CREATE TABLE IF NOT EXISTS Templates (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                UserId INTEGER NOT NULL,
                Name TEXT NOT NULL,
                Exercises TEXT NOT NULL,
                CreatedDate DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(UserId) REFERENCES Users(Id)
            )", connection);

            }
        }

        private void UpdateUI()
        {
            if (_currentUserId > 0)
            {
                // Пользователь авторизован
                LoginButton.Visibility = Visibility.Collapsed;
                RegisterButton.Visibility = Visibility.Collapsed;
                LogoutButton.Visibility = Visibility.Visible;
                UserInfoTextBlock.Visibility = Visibility.Visible;
                UserInfoTextBlock.Text = $"Вы вошли как: {_currentUsername}";
            }
            else
            {
                // Пользователь не авторизован
                LoginButton.Visibility = Visibility.Visible;
                RegisterButton.Visibility = Visibility.Visible;
                LogoutButton.Visibility = Visibility.Collapsed;
                UserInfoTextBlock.Visibility = Visibility.Collapsed;
            }
        }

        private void ViewTemplatesButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUserId <= 0)
            {
                MessageBox.Show("Пожалуйста, войдите или зарегистрируйтесь!");
                return;
            }

            // Здесь код для открытия окна просмотра шаблонов
            var viewTemplatesWindow = new ViewTemplatesWindow(_currentUserId, _connectionString);
            viewTemplatesWindow.Owner = this;
            viewTemplatesWindow.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            viewTemplatesWindow.ShowDialog();
        }
        private void WorkoutHistoryButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUserId <= 0)
            {
                MessageBox.Show("Пожалуйста, войдите или зарегистрируйтесь!");
                return;
            }
            var historyWindow = new WorkoutHistory();

            try
            {
                string filePath = "workout_history.json";
                if (File.Exists(filePath))
                {
                    string json = File.ReadAllText(filePath);
                    var history = JsonConvert.DeserializeObject<List<WorkoutHistoryItem>>(json);
                    historyWindow.HistoryDataGrid.ItemsSource = history;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки истории: {ex.Message}");
            }

            historyWindow.ShowDialog();
        }
        private void StartWorkoutButton_Click(object sender, RoutedEventArgs e)
        {

            if (_currentUserId <= 0)
            {
                MessageBox.Show("Пожалуйста, войдите или зарегистрируйтесь!");
                return;
            }
            var workoutSelectionWindow = new WorkoutSelectionWindow()
            {
                Owner = this,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };

            workoutSelectionWindow.ShowDialog();
        }

        private void AddTemplateButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUserId <= 0)
            {
                MessageBox.Show("Пожалуйста, войдите или зарегистрируйтесь!");
                return;
            }
            AddTemplateWindow addTemplateWindow = new AddTemplateWindow(_connectionString, _currentUserId);

            // Устанавливаем текущее окно как владельца
            addTemplateWindow.Owner = this;

            // Настраиваем положение окна
            addTemplateWindow.WindowStartupLocation = WindowStartupLocation.CenterOwner;

            // Открываем окно
            addTemplateWindow.ShowDialog();
        }


        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            var loginWindow = new LoginWindow(_connectionString);
            if (loginWindow.ShowDialog() == true)
            {
                _currentUserId = loginWindow.UserId;
                _currentUsername = loginWindow.Username;
                UpdateUI();
            }
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            var registerWindow = new RegisterWindow(_connectionString);
            if (registerWindow.ShowDialog() == true)
            {
                _currentUserId = registerWindow.UserId;
                _currentUsername = registerWindow.Username;
                UpdateUI();
            }
        }
        private void AIAssistantButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUserId <= 0)
            {
                MessageBox.Show("Пожалуйста, войдите или зарегистрируйтесь!");
                return;
            }

            var aiWindow = new AIAssistantWindow
            {
                Owner = this,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };
            aiWindow.ShowDialog();
        }
        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            _currentUserId = -1;
            _currentUsername = "";
            UpdateUI();
            MessageBox.Show("Вы успешно вышли из системы.");
        }
    }
}