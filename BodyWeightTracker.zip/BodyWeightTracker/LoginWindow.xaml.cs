﻿using System;
using System.Data.SQLite;
using System.Windows;

namespace BodyWeightTracker
{
    public partial class LoginWindow : Window
    {
        private readonly string _connectionString;
        public int UserId { get; private set; } = -1;
        public string Username { get; private set; } = "";

        public LoginWindow(string connectionString)
        {
            InitializeComponent();
            _connectionString = connectionString;
        }
        private void CheckSavedCredentials()
        {
            if (Properties.Settings.Default.RememberMe &&
                !string.IsNullOrEmpty(Properties.Settings.Default.AuthToken))
            {
                // Пробуем автоматически войти
                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }
        private void RegisterLink_Click(object sender, RoutedEventArgs e)
        {
            // Открываем окно регистрации, передавая connectionString
            RegisterWindow registerWindow = new RegisterWindow(_connectionString);
            registerWindow.Show();
            this.Close();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;
            

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин и пароль!");
                return;
            }

            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();
                var command = new SQLiteCommand(
                    "SELECT Id, Username FROM Users WHERE Username = @Username AND Password = @Password",
                    connection);

                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password); // В реальном приложении используйте хеширование!

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        UserId = reader.GetInt32(0);
                        Username = reader.GetString(1);
                        DialogResult = true;
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль!");
                    }
                }
            }
        }
    }
}